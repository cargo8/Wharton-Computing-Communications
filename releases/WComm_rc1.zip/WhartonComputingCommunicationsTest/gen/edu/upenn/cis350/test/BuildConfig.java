/** Automatically generated file. DO NOT MODIFY */
package edu.upenn.cis350.test;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}