package edu.upenn.cis350;

public class Settings {

	public static final String APPLICATION_ID = "FWyFNrvpkliSb7nBNugCNttN5HWpcbfaOWEutejH";
	public static final String CLIENT_ID = "SZoWtHw28U44nJy8uKtV2oAQ8suuCZnFLklFSk46";
	public static final String SUPERUSER_EMAIL = "kuyumcuarda@gmail.com";
	
}
